# ApiKeyResponseDailyQuota

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Int** |  | 
**used** | **Int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


